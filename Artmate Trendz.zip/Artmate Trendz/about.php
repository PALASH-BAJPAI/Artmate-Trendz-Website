<!DOCTYPE html>
<html lang="en">

<head>
    <title>Artmate Trendz</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lovers+Quarrel" rel="stylesheet">
    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/ionicons.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="images/top-logo.png" type="image/icon type">


    <style>
        .flex-container {
            max-width: 100%;
            display: flex;
            flex-wrap: wrap;
            padding-bottom: 15px;
        }
        
        .point {
            flex: 1;
            padding: 0 15px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        
   
        
        img {
            width: 250px;
            height: 250px;
            margin: auto;
        }
        
        h3 {
            display: flex;
            justify-content: center;
        }
        
        .note {
            color: black;
            opacity: 1;
            font-size: 20px;
            margin-left: 24px;
        }
        
        hr {
            border: none;
            border-top: 1px dashed rgb(49, 49, 49);
            color: #fff;
            background-color: #fff;
            height: 1px;
            width: 50%;
            margin-bottom: 20px;
        }
        
        .line1 {
            border: none;
            border-top: 3px dashed #f00;
            color: #fff;
            background-color: #fff;
            height: 2px;
            width: 90%;
            margin-top: 30px;
            margin-bottom: 40px;
        }
        
        .list {
            margin-left: 20px;
            margin-bottom: 20px;
            margin-right: 20px;
        }
        
        .list ul {
            list-style-type: none;
        }
        
        .list ul li {
            font-size: 20px;
            padding: 3px 0;
            color: black;
            opacity: 0.8;
        }
        
        .point1 img {
            float: left;
            padding: 0 10px;
        }
        
        .point1 p {
            left: 10%;
            font-size: 20px;
            letter-spacing: 3px;
        }
        
        .point1 {
            display: inline-block;
            padding: 0 20px;

        }
        
        .content2 {
            color: black;
            font-style:bold;


        }
        
        .content1 {
            color: red;
            font-style:bold;

        }
        .grow {
             transition: all .2s ease-in-out;
             padding:5px;
             margin:5px;
              }
        .grow:hover { transform: scale(1.1);
        }
    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light ftco-navbar-light-2" id="ftco-navbar">
        <div class="container">
            <a class="navbar-brand" href="index.php"><img src="images/f2.png" style="width: 80px;height:70px">
                <a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Content
	      </button>

                    <div class="collapse navbar-collapse" id="ftco-nav">
                        <ul class="navbar-nav ml-auto">
                            <li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
                            <li class="nav-item active"><a href="about.php" class="nav-link">About</a></li>
                            <li class="nav-item"><a href="courses.php" class="nav-link">Courses</a></li>
                            <li class="nav-item"><a href="art.php" class="nav-link">Art</a></li>
                            <li class="nav-item"><a href="gallery.php" class="nav-link">Gallery</a></li>
                            <li class="nav-item"><a href="contact.php" class="nav-link">Contact us</a></li>
                        </ul>
                    </div>
        </div>
    </nav>
    <!-- END nav -->

    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/bg_4.jpg');" data-stellar-background-ratio="0.5">
        <div class="overlay"></div>
        <div class="container">
            <div class="row no-gutters slider-text align-items-center justify-content-center">
                <div class="col-md-9 ftco-animate text-center">
                    <h1 class="mb-2 bread">ABOUT US</h1>
                    <p class="breadcrumbs"><span class="mr-2"><a href="index.php">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>About us <i class="ion-ios-arrow-forward"></i></span></p>
                </div>
            </div>
        </div>
    </section>



    <section>
        <div class=" heading-section" style=" display:flex;justify-content:center;padding:30px">
            <span class="subheading" style="font-size:100px;color: rgba(247, 119, 0, 0.938);">Our Success Pillar</span>
        </div>
        <h1 class="heading-1"></h1>
        <div class="flex-container">
            <div class="point">
                <h3>MENTORSHIP</h3>
                <img src="images/lunch-4.jpg" class="grow">
                <p class="content"> We always try to contribute our best to the student with tailoring teaching methods. We value our students by taking forward their ideas, opinions and learning techniques.</p>
            </div>

            <div class="point">
                <h3>FLEXIBILITY</h3>
                <img src="images/lunch-5.jpg" class="grow">
                <p class="content">Our faculty introduces friendly teaching which makes student in comfortable learning. We create a platform for one to one interaction, special sessions on suspicion areas. </p>
            </div>

            <div class="point">
                <h3>RESPONSIBILITY</h3>
                <img src="images/lunch-6.jpg" class="grow">
                <p class="content">We provide continuous assessment on students learning by developing and delivering digital content and assessments.</p>
            </div>
        </div>
        <p class="note text-center">We stress up on importance of communication, interaction and cohesiveness among students, faculty and parents.</p>
    </section>

    <hr class="line1">






    <div class=" heading-section mb-3" style=" display:flex;justify-content:center;padding:30px">
        <span class="subheading text-center" style="font-size:100px;color: rgba(247, 119, 0, 0.938);">Our Unique Specifications</span>
    </div>

    <section class="mb-0 pt-3 pb-3" style="margin:30px; padding:50px;">

        <div class="point1" style="left:0px;padding-right:15%" align="left">
            <img src="images/2-1.png" style="width:105px;height:85px" class="grow">
            <p class="content2">Coaching in both online and offline platforms. Special classes and doubt sessions based on student needs.</p>
        </div>

        <hr>


        <div class="point1" style="right:0px;padding-left:15%" align="right">
            <img src="images/1-1.png" style="width:105px;height:85px;float:right" class="grow">
            <p class="content1">Drawing classes by experienced National Artists. Frequent counseling with professional architects.</p>
        </div>

        <hr>

        <div class="point1" style="left:0px;padding-right:15%" align="left">
            <img src="images/3-1.png" style="width:105px;height:85px" class="grow">
            <p class="content2">Experienced aptitude faculty. Delivering special techniques and easy methods in scoring aptitude.</p>
        </div>

        <hr>
        <div class="point1" style="right:0px;padding-left:15%" align="right">
            <img src="images/7-1.png" style="width:105px;height:85px;float:right" class="grow">
            <p class="content1">College guidance after results and during counseling for making best decisions in college selection.</p>
        </div>
        <hr>

        <div class="point1" style="left:0px;padding-right:15%" align="left">
            <img src="images/4-1.png" style="width:105px;height:85px" class="grow">
            <p class="content2">Examination suggestions and classes with top rankers of JEE B.Arch and NATA. Student and coach interactive sessions for special guidance, in depths and improvement areas.</p>
        </div>
        <hr>
        <div class="point1" style="right:0px;padding-left:15%" align="right">
            <img src="images/5-1.png" style="width:105px;height:85px;float:right" class="grow">
            <p class="content1">Conducts daily and weekly practice tests, spot evaluation with suggested answers and special guidance.</p>
        </div>
        <hr>
        <div class="point1" style="left:0px;padding-right:15%" align="left">
            <img src="images/6-1.png" style="width:105px;height:85px" class="grow">
            <p class="content2">Customized study material, work books, practice manuals. Additional study material will be provided based on requirement.</p>
        </div>

        <hr>
        <div class="point1" style="right:0px;padding-left:15%" align="right">
            <img src="images/8-1.png" style="width:105px;height:85px;float:right" class="grow">
            <p class="content1">Friendly teaching methods. Special aptitude workshops for development of visualization skills.</p>
        </div>
    </section>
   




<!-- footer -->
    <?php include "includes/footer.php"; ?>