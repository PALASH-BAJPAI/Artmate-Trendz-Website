<!-- header-links -->
<?php include "includes/header_links.php"; ?>

<style>
.block-20 {
	-webkit-transform: scale(1);
	transform: scale(1);
	-webkit-transition: .3s ease-in-out;
	transition: .3s ease-in-out;
}
.block-20:hover {
	-webkit-transform: scale(0.9);
	transform: scale(0.9);
}
</style>




      <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light ftco-navbar-light-2" id="ftco-navbar">
        <div class="container">
        <a class="navbar-brand" href="index.php"><img src="images/f2.png" style="width: 80px;height:70px">
                <a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="oi oi-menu"></span> Content
          </button>

          <div class="collapse navbar-collapse" id="ftco-nav">
            <ul class="navbar-nav ml-auto">
            <li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
            <li class="nav-item"><a href="about.php" class="nav-link">About</a></li>
            <li class="nav-item"><a href="courses.php" class="nav-link">Courses</a></li>
            <li class="nav-item active"><a href="art.php" class="nav-link">Art</a></li>
            <li class="nav-item"><a href="gallery.php" class="nav-link">Gallery</a></li>
            <li class="nav-item"><a href="contact.php" class="nav-link">Contact us</a></li>
            </ul>
          </div>
        </div>
      </nav>
    <!-- END nav -->


    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/bg_4.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-2 bread">ART</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.php">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>ART <i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>


    <p class="pl-5 pr-5 pt-5 pb-0 ml-4 mr-4 text-center font-weight-normal" style="color:black;font-family:Georgia,serif;">Artmate helps students refine their art techniques, develop their critical thinking skills. 
    Artmate classes are both fun and educational way to unwind after the school day. Custom art course
     in priority, offers one on one art lessons for every artist interested in further developing skills,
      working on a special project, or fulfilling portfolio requirement.</p>







	
		<section class="ftco-section bg-light">
			<div class="container">
				<div class="row">


          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a class="block-20"  class="hover13" style="background-image: url('images/art-kids.jpg');">
              </a>
              <div class="text px-4 pt-3 pb-4">
                <div class="meta">
                </div>
                <h3 class="heading" style="color:black">Specialized art course for kids</h3>
                <p class="clearfix">
                  <span class="float-left read">We often tend to forget there is more to art than drawing and colouring. It is a combination of discipline, creativity and instilling cultural values through art. Art is a journey of discovery of creating something new and we would like to invite your child to this journey, so that he/she inculcates patience and increases concentration level and helps them to freely express their creativity and imagination.</span>
                </p>
              </div>
            </div>
          </div>

          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a class="block-20" style="background-image: url('images/art-sketch.jpg');">
              </a>
              <div class="text px-4 pt-3 pb-4">
                <div class="meta">
                </div>
                <h3 class="heading" style="color:black">Sketching and shading</h3>
                <p class="clearfix">
                  <span class="float-left read">To develop freehand drawing sketching is very essential. One can learn the art of drawing, the techniques of sketching and shading with graphite pencils, charcoal, colour pencils and create beautiful pieces of artwork.</span>
                </p>
              </div>
            </div>
          </div>

          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a class="block-20" style="background-image: url('images/art-water.jpg');">
              </a>
              <div class="text px-4 pt-3 pb-4">
                <div class="meta">
                </div>
                <h3 class="heading" style="color:black">Water colour painting</h3>
                <p class="clearfix">
                  <span class="float-left read">The traditional and most supporting medium, require spontaneity. It is a lot of fun to handle this medium. But no medium can match the delicate luminosity of transparent water colour. You can enjoy the beauty water colour learning in Artmate.</span>
                </p>
              </div>
            </div>
          </div>

          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a class="block-20" style="background-image: url('images/art-portrait.jpg');">
              </a>
              <div class="text px-4 pt-3 pb-4">
                <div class="meta">
                </div>
                <h3 class="heading" style="color:black">Portrait Art</h3>
                <p class="clearfix">
                  <span class="float-left read">Portray emotions. Learn the nuances of drawing facial features and art of making realistic portrait. Show your skills off to your friends or surprise your loved ones with a presentation.</span>
                </p>
              </div>
            </div>
          </div>

          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a class="block-20" style="background-image: url('images/art-oilpastels.jpg');">
              </a>
              <div class="text px-4 pt-3 pb-4">
                <div class="meta">
                </div>
                <h3 class="heading" style="color:black">Oil pastels</h3>
                <p class="clearfix">
                  <span class="float-left read">One of the best medium for children and adults also. With Artmate you can create beautiful artworks with oil pastels.</span>
                </p>
              </div>
            </div>
          </div>

          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a class="block-20" style="background-image: url('images/art-oilpaint.jpg');">
              </a>
              <div class="text px-4 pt-3 pb-4">
                <div class="meta">
                </div>
                <h3 class="heading" style="color:black">Oil painting</h3>
                <p class="clearfix">
                  <span class="float-left read">One of the traditional medium with more flexibility oil painting is great for all who want to get an all-encompassing lesson about the art world.</span>
                </p>
              </div>
            </div>
          </div>


          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a class="block-20" style="background-image: url('images/art-doodle.jpg');">
              </a>
              <div class="text px-4 pt-3 pb-4">
                <div class="meta">
                </div>
                <h3 class="heading" style="color:black">Doodling art</h3>
                <p class="clearfix">
                  <span class="float-left read">Doodling can help in improving your cognitive skills on memory retention, listening, creativity and emotional expression. Learn how to doodle using brush and colour.</span>
                </p>
              </div>
            </div>
          </div>

          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a class="block-20" style="background-image: url('images/art-fabric.jpg');">
              </a>
              <div class="text px-4 pt-3 pb-4">
                <div class="meta">
                </div>
                <h3 class="heading" style="color:black">Fabric painting</h3>
                <p class="clearfix">
                  <span class="float-left read">Create your own design to express yourself through your clothes. You can learn fabric painting and silk painting in Artmate, with more creativity.</span>
                </p>
              </div>
            </div>
          </div>

          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a class="block-20" style="background-image: url('images/art-decorative.jpg');">
              </a>
              <div class="text px-4 pt-3 pb-4">
                <div class="meta">
                </div>
                <h3 class="heading" style="color:black">Decorative art</h3>
                <p class="clearfix">
                  <span class="float-left read">Get creative with various surfaces and techniques in this class when you choose from pot painting, mosaic art, nib painting, sand painting, glass painting, ceramic painting or marble painting.</span>
                </p>
              </div>
            </div>
          </div>


          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a class="block-20" style="background-image: url('images/art-acrylic.jpg');">
              </a>
              <div class="text px-4 pt-3 pb-4">
                <div class="meta">
                </div>
                <h3 class="heading" style="color:black">Acrylic painting</h3>
                <p class="clearfix">
                  <span class="float-left read">All students love acrylic painting and feel extremely accomplished after leaving. As the paint dries quickly, we have to be decisive with our strokes. We can make big works with shorter time. Artmate teaches you to make your own style of artworks.</span>
                </p>
              </div>
            </div>
          </div>

          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a class="block-20" style="background-image: url('images/art-folk.jpg');">
              </a>
              <div class="text px-4 pt-3 pb-4">
                <div class="meta">
                </div>
                <h3 class="heading" style="color:black">Folk art</h3>
                <p class="clearfix">
                  <span class="float-left read">Create colourful figures with intricate designs in madhubani style, practiced in Mithila region of Bihar, or tell a story through your painting using Gond art, practiced by one of the largest tribes in India- the Gond from Madhya Pradesh. Or follow your creative instincts to draw and paint the elements of Mother Nature using simple geometric shapes with Warli art, a style of tribal art from the Sahayadri range in India</span>
                </p>
              </div>
            </div>
          </div>

          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a class="block-20" style="background-image: url('images/art-tanjore.jpg');">
              </a>
              <div class="text px-4 pt-3 pb-4">
                <div class="meta">
                </div>
                <h3 class="heading" style="color:black">Tanjore art</h3>
                <p class="clearfix">
                  <span class="float-left read">Express your divine spirit. Create your own Thanjavur style painting, an old south Indian art form characterized by rich and vivid colours, glittering gold foils overlaid on extensive gesso work and inlay of glass beads.</span>
                </p>
              </div>
            </div>
          </div>






        
			</div>
		</section>


<!-- footer -->
    <?php include "includes/footer.php"; ?>