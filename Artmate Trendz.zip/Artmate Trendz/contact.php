<!-- header-links -->
<?php include "includes/header_links.php"; ?>

<style>
.block-20{
   width: 310px;
    height: 310px;
    margin:auto;
}

.block-20 {
	-webkit-transition: .3s ease-in-out;
	transition: .3s ease-in-out;
}
.block-20:hover {
	-webkit-transform: scale(1.1);
	transform: scale(1.1);
}
.address{
    margin:auto;
    width:60%;
}
.center {
text-align: center;
padding:10px;
}

</style>


	  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light ftco-navbar-light-2" id="ftco-navbar">
	    <div class="container">
      <a class="navbar-brand" href="index.php"><img src="images/f2.png" style="width: 80px;height:70px">
                <a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Content
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
          <li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
          <li class="nav-item"><a href="about.php" class="nav-link">About</a></li>
          <li class="nav-item"><a href="courses.php" class="nav-link">Courses</a></li>
          <li class="nav-item"><a href="art.php" class="nav-link">Art</a></li>
          <li class="nav-item"><a href="gallery.php" class="nav-link">Gallery</a></li>
          <li class="nav-item active"><a href="contact.php" class="nav-link">Contact us</a></li>
	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->


    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/bg_4.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-2 bread">Contact</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.html">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Contact <i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>





<!-- Address -->
<div class="center">
<h1>Reach us at</h1>
</div>
<div class="address">
<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15301.583636321304!2d80.6646134!3d16.5060985!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x71e4ac4d0bc2f8d6!2sNATA%2CJeeMains%20B.Architecture%20%26%20Nid%20Training%20Institute%20%7C%20Artmate%20trendz!5e0!3m2!1sen!2sin!4v1614587064370!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="1" loading="lazy">
</iframe>
</div>


<div class="center">
<h1>Contact Us</h1>
</div>
<div class="d-flex justify-content-center flex-wrap">

<div class="card" style="width: 18rem;margin:20px">
  <img src="images/call.jpg" class="card-img-top" alt="..." style="padding-top: 40px;margin-bottom:50px;height:120px">
  <div class="card-body">
    <p class="card-text">Feel Free to contact us at:<br>7989056463 / 7799308775</p>
    <a href="tel:+917989056463" class="btn btn-primary">Call Us</a>
    <a href="tel:+917799308775" class="btn btn-primary">Call Us</a>
  </div>
</div>

<div class="card" style="width: 18rem; margin:20px">
  <img src="images/mail.png" class="card-img-top" alt="..." style="padding-top: 40px;margin-bottom:50px;height:120px">
  <div class="card-body">
    <p class="card-text">Feel Free to mail us at:<br> info@artmatetrendz.in</p>
    <a href = "mailto: abc@example.com" class="btn btn-primary">Mail Us</a>
  </div>
</div>

<div class="card" style="width: 18rem; margin:20px">
  <img src="images/jd.jpg" class="card-img-top" alt="..." style="padding-top: 10px">
  <div class="card-body">
    <p class="card-text">Reach us at:<br>JustDial</p>
    <a href = "https://www.justdial.com/Vijayawada/Artmate-Trendz-Beside-Gurunanak-Colony-Andhra-Bank-Beside-Road-End-Srinagar-Colony/0866PX866-X866-190626141619-I3F1_BZDET" class="btn btn-primary">Just dial</a>
  </div>
</div>

</div>



<!-- footer -->
<?php include "includes/footer.php"; ?>





