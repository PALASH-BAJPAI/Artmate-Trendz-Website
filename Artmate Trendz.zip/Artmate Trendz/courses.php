<!DOCTYPE html>
<html lang="en">

<head>
    <title>Artmate Trendz</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Lovers+Quarrel" rel="stylesheet">
    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">
    <link rel="stylesheet" href="css/aos.css">
    <link rel="stylesheet" href="css/ionicons.min.css">
    <link rel="stylesheet" href="css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="css/jquery.timepicker.css">
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="images/top-logo.png" type="image/icon type">


    <style>
        .flex-container {
            max-width: 100%;
            display: flex;
            flex-wrap: wrap;
            padding-bottom: 15px;
        }

        .point {
            flex: 1;
            padding: 0 15px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .content {
            max-width: 100%;
            justify-content: center;
        }

        img {
            width: 250px;
            height: 250px;
            margin: auto;
        }

        h2 {
            display: flex;
            justify-content: center;
        }



        hr {
            border: none;
            border-top: 3px dashed orange;
            color: #fff;
            background-color: #fff;
            height: 1px;
            width: 50%;
            margin-bottom: 30px;
            margin-top:40px;
        }
        .about{
            color:black;
        }
        .grow {
             transition: all .2s ease-in-out;
              }
        .grow:hover { transform: scale(1.1);
        }



    </style>
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light ftco-navbar-light-2" id="ftco-navbar">
        <div class="container">
            <a class="navbar-brand" href="index.php"><img src="images/f2.png" style="width: 80px;height:70px">
                <a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Courses
	      </button>

                    <div class="collapse navbar-collapse" id="ftco-nav">
                        <ul class="navbar-nav ml-auto">
                            <li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
                            <li class="nav-item"><a href="about.php" class="nav-link">About</a></li>
                            <li class="nav-item active"><a href="courses.php" class="nav-link">Courses</a></li>
                            <li class="nav-item"><a href="art.php" class="nav-link">Art</a></li>
                            <li class="nav-item"><a href="gallery.php" class="nav-link">Gallery</a></li>
                            <li class="nav-item"><a href="contact.php" class="nav-link">Contact us</a></li>
                        </ul>
                    </div>
        </div>
    </nav>
    <!-- END nav -->





    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/bg_4.jpg');" data-stellar-background-ratio="0.5">
        <div class="overlay"></div>
        <div class="container">
            <div class="row no-gutters slider-text align-items-center justify-content-center">
                <div class="col-md-9 ftco-animate text-center">
                    <h1 class="mb-2 bread">Courses</h1>
                    <p class="breadcrumbs"><span class="mr-2"><a href="index.php">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Courses <i class="ion-ios-arrow-forward"></i></span></p>
                </div>
            </div>
        </div>
    </section>


<!-- Architecture -->

    <section>
        <div class=" heading-section" style=" display:flex;justify-content:center;padding:30px">
            <span class="subheading" style="font-size:100px;color: rgba(247, 119, 0, 0.938);">Architecture</span>
        </div>
        <p class="about text-center px-3 m-3 pb-4">Architecture is a challenging, fascinating and inspirational career that puts you at the forefront of cutting edge innovations and technologies to help improve the lives of people while enabling you to express your own creativity. As an architect you work with clients and users designing buildings that are beautiful unique safe and functional. It involves multiple levels from designing single housing units to entire towns and cities. Architects are responsible for designing buildings which are sustainable affordable and accessible making them a very indispensable part of the society. It is a career for the most resilient and creative students who wish to create a tangible change in the world around them.</p>
        <div class="flex-container">


<!-- ---------------------------------------------------------------------------------------- -->
<!-- JEE B.Arch -->
        <div class="point mb-5">
                <h2 class="grow">JEE B.Arch</h2>
                <img src="images/course-1.jpg">
                <p class="content">Architecture is the study of the artistic and organisational aspects or construction. B. Arch course is designed in a way that it enables you to learn space management for maximum utility along with architectural planning and design.</p>

                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-warning btn-sm btn-block mb-2" style="width:200px" data-toggle="modal" data-target="#staticBackdrop1">
                        Paper Pattern
                        </button>
                        <!-- Modal -->
                        <div class="modal fade" id="staticBackdrop1" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="staticBackdropLabel">Paper Pattern</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <p>JEE B.Arch is being conducted by National Testing Agency (NTA) twice a year.</br>
                                    Total marks: 400</br></br>
                                    Mode of exam: Online-for maths and general aptitude.
                                                   Offline-for drawing.</br></br>

                                    Marking scheme: 4 marks will be awarded for correct answer and -1 for a wrong answer. No mark will be awarded for an unattempt question.</br>
                                    Part-A: 25Q x 4M = 100 (Maths)</br>
                                    Part-B: 50Q x 4M = 200 (General Aptitude & Logical Reasoning)</br>
                                    Part-C: 2Q x 50M = 100 (Drawing)</br>
                                </p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-primary" data-dismiss="modal">Understood</button>
                            </div>
                            </div>
                        </div>
                        </div>


                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-warning btn-sm btn-block mb-2" style="width:200px" data-toggle="modal" data-target="#staticBackdrop2">
                        Syllabus
                        </button>
                        <!-- Modal -->
                        <div class="modal fade" id="staticBackdrop2" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="staticBackdropLabel">Syllabus</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <p><b>Part-A:</b> It will be a math test with 20 objective questions and 5 integer type of questions for 100 marks.</p>
                                        <ol>
                                            <li>Sets, relations and Functions</li>
                                            <li>Complex numbers and Quadratic equations</li>
                                            <li>Matrices and Determinants</li>
                                            <li>Permutations and Combinations</li>
                                            <li>Mathematical induction</li>
                                            <li>Binomial theorem and its simple applications</li>
                                            <li>Sequences and Series</li>
                                            <li>Limits, Continuity and Differentiability</li>
                                            <li>Integral Calculus</li>
                                            <li>Differential Equations</li>
                                            <li>Coordinate Geometry</li>
                                            <li>3D Geometry</li>
                                            <li>Vector Algebra</li>
                                            <li>Statics and Probability</li>
                                            <li>Trigonometry</li>
                                            <li>Mathematical Reasoning</li>
                                        </ol>
                                <br>
                                <p><b>PART-B: </b>It will consist of Aptitude test with 50 questions for 200 marks.<br>
                                                    35 questions from this part test the reasoning ability, Analytical skills of the student.</br>
                                                    Remaining 15 questions tests the student general awareness.</br>
                                </p>

                                <br>
                                <p><b>PART-C:</b>  It will be a drawing test with 2 questions. One will be a memory drawing and the other is a 2D design.<br>
                                            Note: Drawing questions have to be attempted on the separate drawing sheet placed with the answer sheet.
                                </p>


                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-primary" data-dismiss="modal">Understood</button>
                            </div>
                            </div>
                        </div>
                        </div>


                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-warning btn-sm btn-block mb-2" style="width:200px" data-toggle="modal" data-target="#staticBackdrop3">
                        Colleges
                        </button>
                        <!-- Modal -->
                        <div class="modal fade" id="staticBackdrop3" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="staticBackdropLabel">Colleges</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                    <ol>
                                    <li>National Institute of Technology Calicut</li>
                                    <li>National Institute of Technology Trichy</li>
                                    <li>National Institute of Technology Rourkela</li>
                                    <li>Maulana Azad National Institute of Technology Bhopal</li>
                                    <li>Malaviya National Institute of Technology Jaipur</li>
                                    <li>National Institute of Technology patna</li>
                                    <li>National Institute of Technology Hamirpur</li>
                                    <li>National Institute of Technology Raipur</li>
                                    <li>Visvesvaraya National Institute of Technology Nagpur</li>
                                    <li>Birla Institute of technology Mesra</li>
                                    <li>Mizoram University, Aizwal</li>
                                    <li>School of Planning and Architecture Delhi</li>
                                    <li>School of Planning and Architecture Bhopal</li>
                                    <li>School of Planning and Architecture Vijayawada</li>
                                    <li>Shri mata vaishnodevi university, Katra</li>
                                    <li>Indian Institute of Engineering Sciences and Technology, Shibpur.</li>
                                    </ol>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-primary" data-dismiss="modal">Understood</button>
                            </div>
                            </div>
                        </div>
                        </div>

            </div>



<!-- ---------------------------------------------------------------------------------------- -->
<!-- NATA -->
            <div class="point mb-5">
                <h2 class="grow">NATA</h2>
                <img src="images/course-2.jpg">
                <p class="content">National Aptitude Test in Architecture (NATA) is a national level entrance exam conducted for candidates seeking admission to undergraduate programmes in Architecture (5-year BArch). NATA exam is conducted by the Council of Architecture (CoA)</p>

                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-warning btn-sm btn-block mb-2" style="width:200px" data-toggle="modal" data-target="#staticBackdrop4">
                        Paper Pattern
                        </button>
                        <!-- Modal -->
                        <div class="modal fade" id="staticBackdrop4" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="staticBackdropLabel">Paper Pattern</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <p> NATA will be held twice a year</br>
                                    Total marks: 200</br></br>
                                    Mode of exam: Online-for maths, physics, chemistry and general aptitude.
                                    Offline for drawing.</br></br>

                                    Marking scheme: 1.5 marks will be awarded for correct answer. No mark will be awarded for an unattempt question or wrong answer.</br>
                                    Part-A: 2Q x 35M = 70 (Drawing)</br>
                                    &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp1Q x 55M = 55 (Drawing)</br>
                                    Part-B: 15Q x 1.5M = 22.5 (MPC)<br>
                                    &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp35Q x 1.5M = 52.5 (General Aptitude & Logical reasoning)</br>
                                </p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-primary" data-dismiss="modal">Understood</button>
                            </div>
                            </div>
                        </div>
                        </div>


                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-warning btn-sm btn-block mb-2" style="width:200px" data-toggle="modal" data-target="#staticBackdrop5">
                        Syllabus
                        </button>
                        <!-- Modal -->
                        <div class="modal fade" id="staticBackdrop5" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="staticBackdropLabel">Syllabus</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <p><b>Part-A:</b>Part-A is to be answered on A4 drawing sheets. Candidate has to attempt three   drawing questions within 135 minutes.</p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-primary" data-dismiss="modal">Understood</button>
                            </div>
                            </div>
                        </div>
                        </div>


                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-warning btn-sm btn-block mb-2" style="width:200px" data-toggle="modal" data-target="#staticBackdrop6">
                        Colleges
                        </button>
                        <!-- Modal -->
                        <div class="modal fade" id="staticBackdrop6" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="staticBackdropLabel">Colleges</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                   <p>All private colleges, universities and state government colleges accept NATA score for admissions.</p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-primary" data-dismiss="modal">Understood</button>
                            </div>
                            </div>
                        </div>
                        </div>

            </div>





            </div>
        </div>


        </div>
    </section>
    <hr >






<!-- ---------------------------------------------------------------------------------------- -->
<!-- Designing -->
<section>
        <div class=" heading-section" style=" display:flex;justify-content:center;padding:30px">
            <span class="subheading" style="font-size:100px;color: rgba(247, 119, 0, 0.938);">Designing</span>
        </div>
        <p class="about text-center px-3 m-3 pb-4">Design is a career stream that candidates pursue at undergraduate (UG), postgraduate (PG), or doctorate (PhD) level to become designers. Design as a career is extremely popular among students having a creative flair. What makes design careers even better is that this stream is vast and offers ample opportunities to students with different talents, skills, and educational background.To pursue a design course, no subject is mandatory. This means that candidates from any educational background have the liberty to pursue their dream career if they have the required skills and aptitude.</p>
        <div class="flex-container">



<!-- ---------------------------------------------------------------------------------------- -->
<!-- NID -->
        <div class="point mb-5">
                <h2 class="grow">NID</h2>
                <img src="images/course-3.jpg">
                <p class="content">The National Institute of Design (NID) is a design school located in Ahmedabad, India. The institute work as an autonomous body under the Department of Industrial Policy and Promotion, Ministry of Commerce and Industry, government of India. In 2010 according to Business Week, NID in its list of top design schools in the world.</p>

                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-warning btn-sm btn-block mb-2" style="width:200px" data-toggle="modal" data-target="#staticBackdrop7">
                        Paper Pattern
                        </button>
                        <!-- Modal -->
                        <div class="modal fade" id="staticBackdrop7" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="staticBackdropLabel">Paper Pattern</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                            <p>Mode of exam: Offline mode (both prelims and studio).
                                </br></br>
                                Prelims exam is for 100 marks with no negative marking. MCQs have aptitude, maths and English. Drawing exam with two or three question (It based on allotment of marks).<br>
                                Those candidates who qualify the prelims stage by clearing the cut-off set by NID for that year are then called for the second stage, studio test.
                                </p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-primary" data-dismiss="modal">Understood</button>
                            </div>
                            </div>
                        </div>
                        </div>


                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-warning btn-sm btn-block mb-2" style="width:200px" data-toggle="modal" data-target="#staticBackdrop8">
                        Syllabus
                        </button>
                        <!-- Modal -->
                        <div class="modal fade" id="staticBackdrop8" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="staticBackdropLabel">Syllabus</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                            <h3>Prelims</h3>
                                        <ol>
                                        <li>Outline for beginners </li>
                                        <li>Colour Terminology </li>
                                        <li>Inspiration & Design Development </li>
                                        <li>Mood, theme & colour inter - relationship </li>
                                        <li>Design Theory</li>
                                        <li>Elements & Principles Of Design </li>
                                        <li>Natural & Geometrical Form </li>
                                        <li>Innovation in Design </li>
                                        <li>Principles of Composition </li>
                                        <li>Lettering</li>
                                        <li>Optical Illusion</li>
                                        <li>Understanding Light & Shade</li>
                                        <li>Colour Psychology & Optical Illusions</li>
                                        <li>Form & Function </li>
                                        <li>Colour, Pattern & Texture</li>
                                        <li>Theme Development </li>
                                        <li>Creative thinking & writing </li>
                                        <li>Picture Analysis</li>
                                        <li>Visual Logic </li>
                                        <li>Good Design vs. Bad Design </li>
                                        <li>Drawing Fundamentals</li>
                                        <li>Use of Measurements, Scale & proportions</li>
                                        <li>Optical Illusion</li>
                                        <li>Foreshortening & Perspective</li>
                                        <li>Developing Themes & Colour Associations</li>
                                        <li>Inspiration & Creativity</li>
                                        <li>Ornaments & motifs </li>
                                        <li>Memory Drawing </li>
                                        <li>Usage of colour in Compositions </li>
                                        <li>Expression & Emotion</li>
                                        <li>Exercises on imagination</li>
                                        <li>Lateral Thinking </li>
                                        <li>Story pictures</li>
                                        <li>Presentation Techniques</li>
                                        <li>Imagination & Doodling </li>
                                        <li>3D Visualization</li>
                                        <li>Graphics & Pictograms</li>
                                        <li>Innovation & Creation</li>
                                        <li>Design Awareness</li>
                                        <li>Developing Observation</li>
                                        </ol>
                                <br>
                                <h3>NID Studio Test</h3>
                                <ol>
                                    <li>Model Making</li>
                                    <li>Doodling</li>
                                    <li>Meeting with past successful </li>
                                    <li>How to evolve ideas</li>
                                    <li>Audio – Visual Exercises </li>
                                    <li>Material Manipulation</li>
                                    <li>Creative Thinking</li>
                                </ol>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-primary" data-dismiss="modal">Understood</button>
                            </div>
                            </div>
                        </div>
                        </div>


                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-warning btn-sm btn-block mb-2" style="width:200px" data-toggle="modal" data-target="#staticBackdrop9">
                        Colleges
                        </button>
                        <!-- Modal -->
                        <div class="modal fade" id="staticBackdrop9" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="staticBackdropLabel">Colleges</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                    <ol>
                                    <li>NID Ahmedabad, Est. 1961</li>
                                    <li>NID Bengaluru, Est. 2006</li>
                                    <li>NID Gandhinagar, Est. 2004</li>
                                    <li>NID Andhra Pradesh, Est. 2015</li>
                                    <li>NID Madhya Pradesh, Est. 2019</li>
                                    <li>NID Haryana, est. 2016</li>
                                    <li>NID Assam, Est. 2019</li>

                                    </ol>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-primary" data-dismiss="modal">Understood</button>
                            </div>
                            </div>
                        </div>
                        </div>

            </div>




<!-- ---------------------------------------------------------------------------------------- -->
<!-- NIFT -->
            <div class="point mb-5">
                <h2 class="grow">NIFT</h2>
                <img src="images/course-4.jpg">
                <p class="content">It is the pioneering institute of fashion education in the country and has been in the vanguard of providing professional human resource to the textile and apparel industry. It was made a statutory institute in 2006 by an Act of the Indian Parliament with the President of India as ‘Visitor’ and has full-fledged campuses all across the country.</p>

                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-warning btn-sm btn-block mb-2" style="width:200px" data-toggle="modal" data-target="#staticBackdrop10">
                        Paper Pattern
                        </button>
                        <!-- Modal -->
                        <div class="modal fade" id="staticBackdrop10" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="staticBackdropLabel">Paper Pattern</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <p>Mode of exam: Offline mode (both prelims and studio).
                                </p>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-primary" data-dismiss="modal">Understood</button>
                            </div>
                            </div>
                        </div>
                        </div>


                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-warning btn-sm btn-block mb-2" style="width:200px" data-toggle="modal" data-target="#staticBackdrop11">
                        Syllabus
                        </button>
                        <!-- Modal -->
                        <div class="modal fade" id="staticBackdrop11" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="staticBackdropLabel">Syllabus</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                            <h3>Prelims</h3>
                            <p>150 mark exam in 3 hours. No negative marking.</br>
                                English Comprehension - 25 </br>
                                Quantitative Ability - 20 </br>
                                Communication Ability - 25 </br>
                                Analytical Ability - 15 </br>
                                General Knowledge and Current Affairs – 15</br>
                            </p>
                            <br>


                            <h3>Studio Test</h3>
                                        <ol>
                                                <li>Model Making</li>
                                                <li>Doodling</li>
                                                <li>Meeting with past successful </li>
                                                <li>How to evolve ideas</li>
                                                <li>Audio – Visual Exercises </li>
                                                <li>Material Manipulation</li>
                                                <li>Creative Thinking</li>
                                        </ol>
                                <br>

                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-primary" data-dismiss="modal">Understood</button>
                            </div>
                            </div>
                        </div>
                        </div>


                        <!-- Button trigger modal -->
                        <button type="button" class="btn btn-warning btn-sm btn-block mb-2" style="width:200px" data-toggle="modal" data-target="#staticBackdrop12">
                        Colleges
                        </button>
                        <!-- Modal -->
                        <div class="modal fade" id="staticBackdrop12" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="staticBackdropLabel">Colleges</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                    <ol>
                                        <li>NIFT New Delhi</li>
                                        <li>NIFT Navi Mumbai</li>
                                        <li>NIFT Bengaluru</li>
                                        <li>NIFT Chennai</li>
                                        <li>NIFT Kolkata</li>
                                        <li>NIFT Hyderabad</li>
                                        <li>NIFT Patna</li>
                                        <li>NIFT Bhopal</li>
                                        <li>NIFT Kannur</li>
                                        <li>NIFT Gandhinagar</li>
                                        <li>NIFT Jodhpur</li>
                                        <li>NIFT Bhuvaneswar</li>
                                        <li>NIFT Raebareli</li>
                                        <li>NIFT Shillong</li>
                                        <li>NIFT Srinagar</li>
                                        <li>NIFT Kangra</li>
                                    </ol>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-primary" data-dismiss="modal">Understood</button>
                            </div>
                            </div>
                        </div>
                        </div>

            </div>

            </div>
        </div>


        </div>
    </section>




<!-- footer -->
    <?php include "includes/footer.php"; ?>