<!-- header-links -->
<?php include "includes/header_links.php"; ?>

<style>
.block-20{
   width: 310px;
    height: 310px;
    margin:auto;
}

.block-20 {
	-webkit-transition: .3s ease-in-out;
	transition: .3s ease-in-out;
}
.block-20:hover {
	-webkit-transform: scale(1.1);
	transform: scale(1.1);
}
hr {
    border-top: 1px dashed rgb(49, 49, 49);
    color: blue;
    background-color: rgb(49,49,49);
    height: 1px;
    width: 90%;
    margin-top:70px;
    margin-bottom:35px;
}
.line1 {
    border: none;
    border-top: 3px dashed #f00;
    color: #fff;
    background-color: #fff;
    height: 2px;
    width: 90%;
}
.center {
text-align: center;
margin-bottom:35px;

}

</style>


	  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light ftco-navbar-light-2" id="ftco-navbar">
	    <div class="container">
      <a class="navbar-brand" href="index.php"><img src="images/f2.png" style="width: 80px;height:70px">
        <a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Content
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
          <li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
          <li class="nav-item"><a href="about.php" class="nav-link">About</a></li>
          <li class="nav-item"><a href="courses.php" class="nav-link">Courses</a></li>
          <li class="nav-item"><a href="art.php" class="nav-link">Art</a></li>
          <li class="nav-item active"><a href="gallery.php" class="nav-link">Gallery</a></li>
          <li class="nav-item"><a href="contact.php" class="nav-link">Contact us</a></li>
	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->





    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/bg_4.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-2 bread">Gallery</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.html">Home <i class="ion-ios-arrow-forward"></i></a></span> <span>Gallery <i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>




		<section class="ftco-section bg-light">




<div class="container">
<div class="center">
<h1>2020 Success Celebrations</h1>
<p class="content"> We continue to maintain the legacy of producing the best results in exams like Jee B.Arch, Nata, etc. Even in such a period of lockdown, we maintained the quality of education and training and thus got great success in 2020.</p>
</div>

				<div class="row">
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="#" class="block-20" style="background-image: url('images/a1-min.jpg');">
              </a>
            </div>
          </div>


          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="#" class="block-20" style="background-image: url('images/a2-min.jpg');">
              </a>
            </div>
          </div>


          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="#" class="block-20" style="background-image: url('images/a3-min.jpg');">
              </a>
            </div>
          </div>
</div>



<hr class="line1">
<div class="center">
<h1>Live sketching at railway station</h1>
<p class="content">We always believe in “Learn by Fun” and hence conduct some learning sessions outside the class where we get inspiration from the world around us and try to depict them in our sheets.
</p>
</div>
<div class="container d-flex flex-wrap">
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="#" class="block-20" style="background-image: url('images/c1-min.jpg');">
              </a>
            </div>
          </div>


          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="#" class="block-20" style="background-image: url('images/c2-min.jpg');">
              </a>
            </div>
          </div>

          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="#" class="block-20" style="background-image: url('images/c3-min.jpg');">
              </a>
            </div>
          </div>

          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="#" class="block-20" style="background-image: url('images/c4-min.jpg');">
              </a>
            </div>
          </div>


          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="#" class="block-20" style="background-image: url('images/c5-min.jpg');">
              </a>
            </div>
          </div>

          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="#" class="block-20" style="background-image: url('images/c6-min.jpg');">
              </a>
            </div>
          </div>
</div>







<hr class="line1">
<div class="center">
<h1>2019 Success Celebrations</h1>
<p class="content">2019 has been a special year and hence all our hard work and dedication resulted in great results in exams.</p>
</div>
<div class="container d-flex flex-wrap">
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="#" class="block-20" style="background-image: url('images/b2-min.jpg');">
              </a>
            </div>
          </div>


          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="#" class="block-20" style="background-image: url('images/b1-min.jpg');">
              </a>
            </div>
          </div>

          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="#" class="block-20" style="background-image: url('images/b3-min.jpg');">
              </a>
            </div>
          </div>


</div>




<hr class="line1">
<div class="center">
<h1>Spectrum art competition</h1>
<p class="content">Competitions help us to evaluate ourselves better and thus such competitions are conducted by us where a large number of participants compete in the field of drawings to prove themselves best.
</p>
</div>
<div class="container d-flex flex-wrap">
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="#" class="block-20" style="background-image: url('images/d1.jpg');">
              </a>
            </div>
          </div>


          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="#" class="block-20" style="background-image: url('images/d2.jpg');">
              </a>
            </div>
          </div>

          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="#" class="block-20" style="background-image: url('images/d3.jpg');">
              </a>
            </div>
          </div>

          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="#" class="block-20" style="background-image: url('images/d4.jpg');">
              </a>
            </div>
          </div>


          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="#" class="block-20" style="background-image: url('images/d5.jpg');">
              </a>
            </div>
          </div>

          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="#" class="block-20" style="background-image: url('images/d6.jpg');">
              </a>
            </div>
          </div>
</div>



<hr class="line1">
<div class="center">
<h1>Model making session</h1>
<p class="content">We try to specialize our students in every field of art and thus such model-making sessions help them to visualize and make 3D art in their classrooms.
</p>
</div>
<div class="container d-flex flex-wrap">
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="#" class="block-20" style="background-image: url('images/e1.jpg');">
              </a>
            </div>
          </div>


          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="#" class="block-20" style="background-image: url('images/e2.jpg');">
              </a>
            </div>
          </div>

          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="#" class="block-20" style="background-image: url('images/e3.jpg');">
              </a>
            </div>
          </div>

          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="#" class="block-20" style="background-image: url('images/e4.jpg');">
              </a>
            </div>
          </div>


          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="#" class="block-20" style="background-image: url('images/e5.jpg');">
              </a>
            </div>
          </div>

          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="#" class="block-20" style="background-image: url('images/e6.jpg');">
              </a>
            </div>
          </div>
</div>



<hr class="line1">
<div class="center">
<h1>Live sketching of Undavalli caves</h1>
<p class="content">Nature is the best art we can imagine thus some outing sessions are conducted so that we can enjoy and learn both together. 
</p>
</div>
<div class="container d-flex flex-wrap">
          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="#" class="block-20" style="background-image: url('images/f1.jpg');">
              </a>
            </div>
          </div>


          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="#" class="block-20" style="background-image: url('images/f2.jpg');">
              </a>
            </div>
          </div>

          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="#" class="block-20" style="background-image: url('images/f3.jpg');">
              </a>
            </div>
          </div>

          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="#" class="block-20" style="background-image: url('images/f4.jpg');">
              </a>
            </div>
          </div>


          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="#" class="block-20" style="background-image: url('images/f5.jpg');">
              </a>
            </div>
          </div>

          <div class="col-md-4 ftco-animate">
            <div class="blog-entry">
              <a href="#" class="block-20" style="background-image: url('images/f6.jpg');">
              </a>
            </div>
          </div>
</div>













		</section>



<!-- footer -->
    <?php include "includes/footer.php"; ?>