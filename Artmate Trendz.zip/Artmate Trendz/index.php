<!-- header-links -->
<?php include "includes/header_links.php"; ?>

<style>
.mobile-testimony{
    display:none;
}
@media (max-width: 700px) {
section,.overlay,.home-slider,.container-fluid,.testimony-section,.carousel-testimony{
  overflow-y: scroll; /* Show scrollbars */
}
}
@media (max-width: 700px) {
.testimony-section-pc{
    display:none;
}
.mobile-testimony{
    display:inherit;
}
}
</style>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
        <div class="container">
            <a class="navbar-brand" href="index.php"><img src="images/f2.png" style="width: 80px;height:70px"></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Content
	      </button>

            <div class="collapse navbar-collapse" id="ftco-nav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a href="index.php" class="nav-link">Home</a></li>
                    <li class="nav-item"><a href="about.php" class="nav-link">About us</a></li>
                    <li class="nav-item"><a href="courses.php" class="nav-link">Courses</a></li>
                    <li class="nav-item"><a href="contact.php" class="nav-link">Contact</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- END nav -->

    <section class="home-slider js-fullheight owl-carousel bg-white scroll">
        <div class="slider-item js-fullheight">
            <div class="overlay"></div>
            <div class="container-fluid p-0">
                <div class="row d-md-flex no-gutters slider-text js-fullheight align-items-center justify-content-end" data-scrollax-parent="true">
                    <div class="one-third order-md-last img js-fullheight" style="background-image: url(images/i2.png)">
                        <div class="overlay"></div>
                    </div>
                    <div class="one-forth d-flex js-fullheight align-items-center ftco-animate" data-scrollax=" properties: { translateY: '70%' }">
                        <div class="text mt-md-5">
                            <h1 class="mb-4">ARTMATE <br> TRENDZ
                                <p class="line" style="color:black; font-size:20px;">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp &nbsp &nbsp &nbsp Aspire to inspire .....
                                    <p>
                            </h1>
                            <p>Best coaching for Nationalized Entrance Exams like JEE B.Arch, NATA, NIFT,NID, CEPT, UCEED and many more..<br>Certification Courses in Arts and Drawings.</p>
                            <p><a href="Artmate trendz.pdf" class="btn btn-primary px-4 py-3 mt-3" download>Brochure</a></p>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>

        <div class="slider-item js-fullheight">
            <div class="overlay"></div>
            <div class="container-fluid p-0">
                <div class="row d-flex no-gutters slider-text js-fullheight align-items-center justify-content-end" data-scrollax-parent="true">
                    <div class="one-third order-md-last img js-fullheight" style="background-image:url(images/hero-2.jpg);">
                        <div class="overlay"></div>
                    </div>
                    <div class="one-forth d-flex js-fullheight align-items-center ftco-animate" data-scrollax=" properties: { translateY: '70%' }">
                        <div class="text mt-md-5">
                            <h1 class="mb-4"> Architecture, Designing <br>and Arts</h1>
                            <p>Teaching in various easy methodologies to improve their skills.</p>
                            <p><a href="Artmate trendz.pdf" class="btn btn-primary px-4 py-3 mt-3" download>Brochure</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>





    <section class="ftco-section ftco-wrap-about ftco-no-pb ftco-no-pt">
        <div class="container">
            <div class="row no-gutters">
                <div class="col-sm-5 img img-2 d-flex align-items-center justify-content-center justify-content-md-end" style="background-image: url(images/about.jpg); position: relative"></div>
                <div class="col-sm-7 wrap-about py-5 ftco-animate">
                    <div class="heading-section mt-5 mb-4">
                        <div class="pl-lg-5 ml-md-5">
                            <span class="subheading">About</span>
                            <h2 class="mb-4">Welcome to ARTMATE TRENDZ</h2>
                        </div>
                    </div>
                    <div class="pl-lg-5 ml-md-5">
                        <p>We focuses on enhancement of student knowledge in moulding bright career which builds analytical skills, develop logical thinking, create artwork, designing and presentations.<br>We guide students with specialized schedules, teaching
                            methods which build the confidence of students to crack their entrance examinations.</p>
                        <h3 class="mt-5">Our Success Pillars</h3>
                        <div class="thumb my-4 d-flex">
                            <a href="#" class="thumb-menu pr-md-4 text-center">
                                <div class="img" style="background-image: url(images/lunch-4.jpg);border:2px outset #eedddd "></div>
                                <h4 style="color:black; opacity:1">MENTORSHIP</h4>
                            </a>
                            <a href="#" class="thumb-menu pr-md-4 text-center">
                                <div class="img" style="background-image: url(images/lunch-5.jpg);border:2px outset #eedddd"></div>
                                <h4 style="color:black; opacity:1">FLEXIBILITY</h4>
                            </a>
                            <a href="#" class="thumb-menu pr-md-4 text-center">
                                <div class="img" style="background-image: url(images/lunch-6.jpg);border:2px outset #eedddd"></div>
                                <h4 style="color:black; opacity:1">RESPONSIBILITY</h4>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>





    <section class=" ftco-counter img im" id="section-counter" style="background-image: url(images/bg_4.jpg);opacity:1" data-stellar-background-ratio="0.5">
        <div class="container">
            <div class="row d-md-flex align-items-center justify-content-center">
                <div class="col-lg-10">
                    <div class="row d-md-flex align-items-center">
                        <div class="col-md d-flex justify-content-center counter-wrap ftco-animate">
                            <div class="block-18">
                                <div class="text">
                                    <strong class="number" data-number="12">0</strong>
                                    <span>Years of Experienced</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md d-flex justify-content-center counter-wrap ftco-animate">
                            <div class="block-18">
                                <div class="text">
                                    <strong class="number" data-number='1500'>0</strong>
                                    <span>Numbers of Students</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md d-flex justify-content-center counter-wrap ftco-animate">
                            <div class="block-18">
                                <div class="text">
                                    <strong class="number" data-number="30">0</strong>
                                    <span>Number of events</span>
                                </div>
                            </div>
                        </div>
                        <div class="col-md d-flex justify-content-center counter-wrap ftco-animate">
                            <div class="block-18">
                                <div class="text">
                                    <strong class="number" data-number="350">0</strong>
                                    <span>Working Days per year</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="ftco-section">
        <div class="container">
            <div class="row justify-content-center mb-5 pb-2">
                <div class="col-md-7 text-center heading-section ftco-animate">
                    <span class="subheading">Achievers List</span>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 col-lg-4 menu-wrap">
                    <div class="heading-menu text-center ftco-animate">
                    </div>
                    <div class="menus d-flex ftco-animate">
                        <div class="menu-img img" style="background-image: url(images/person_3.png);"></div>
                        <div class="text">
                            <div class="d-flex">
                                <div class="one-half">
                                    <h3>Jaswanth neelisetty</h3>
                                </div>
                            </div>
                            <p><span>Chettinad </span><span>college </span><span>of </span><span>Architecture</span></p>
                        </div>
                    </div>
                    <div class="menus d-flex ftco-animate">
                        <div class="menu-img img" style="background-image: url(images/2.png);"></div>
                        <div class="text">
                            <div class="d-flex">
                                <div class="one-half">
                                    <h3>Chetan</h3>
                                </div>
                            </div>
                            <p><span>Wadiyar</span> <span>College</span> <span>of</span> <span>Architecture</span></p>
                        </div>
                    </div>
                    <div class="menus d-flex ftco-animate">
                        <div class="menu-img img" style="background-image: url(images/3.jpg);"></div>
                        <div class="text">
                            <div class="d-flex">
                                <div class="one-half">
                                    <h3>Gaayani.K</h3>
                                </div>
                            </div>
                            <p><span>Wadiyar</span> <span>College</span> <span>of</span> <span>Architecture</span></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 col-lg-4 menu-wrap">
                    <div class="heading-menu text-center ftco-animate">
                    </div>
                    <div class="menus d-flex ftco-animate">
                        <div class="menu-img img" style="background-image: url(images/4.jpg);"></div>
                        <div class="text">
                            <div class="d-flex">
                                <div class="one-half">
                                    <h3>Y.Deepika</h3>
                                </div>
                            </div>
                            <p><span>SV</span> <span>University</span> <span>of</span> <span>Architecture</span></p>
                        </div>
                    </div>
                    <div class="menus d-flex ftco-animate">
                        <div class="menu-img img" style="background-image: url(images/5.jpg);"></div>
                        <div class="text">
                            <div class="d-flex">
                                <div class="one-half">
                                    <h3>T. Praneetha</h3>
                                </div>
                            </div>
                            <p><span>Chettinad</span> <span>College</span> <span>of</span> <span>Architecture</span></p>
                        </div>
                    </div>
                    <div class="menus d-flex ftco-animate">
                        <div class="menu-img img" style="background-image: url(images/6.jpg);"></div>
                        <div class="text">
                            <div class="d-flex">
                                <div class="one-half">
                                    <h3>Srinivas</h3>
                                </div>
                            </div>
                            <p><span>Chettinad</span> <span>College</span> <span>of</span> <span>Architecture</span></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 col-lg-4 menu-wrap">
                    <div class="heading-menu text-center ftco-animate">
                    </div>
                    <div class="menus d-flex ftco-animate">
                        <div class="menu-img img" style="background-image: url(images/7.jpg);"></div>
                        <div class="text">
                            <div class="d-flex">
                                <div class="one-half">
                                    <h3>K.Sai Sree</h3>
                                </div>
                            </div>
                            <p><span>Chettinad</span> <span>College</span> <span>of</span> <span>Architecture</span></p>
                        </div>
                    </div>
                    <div class="menus d-flex ftco-animate">
                        <div class="menu-img img" style="background-image: url(images/8.jpg);"></div>
                        <div class="text">
                            <div class="d-flex">
                                <div class="one-half">
                                    <h3>Jayaram</h3>
                                </div>
                            </div>
                            <p><span>Chettinad</span> <span>College</span> <span>of</span> <span>Architecture</span></p>
                        </div>
                    </div>
                    <div class="menus d-flex ftco-animate">
                        <div class="menu-img img" style="background-image: url(images/9.jpg);"></div>
                        <div class="text">
                            <div class="d-flex">
                                <div class="one-half">
                                    <h3>P.Hareeswar</h3>
                                </div>
                            </div>
                            <p><span>Wadiyar</span> <span>College</span> <span>of</span> <span>Architecture</span></p>
                        </div>
                    </div>
                </div>

                <!--  -->
                <div class="col-md-6 col-lg-4 menu-wrap">
                    <div class="heading-menu text-center ftco-animate">
                    </div>
                    <div class="menus d-flex ftco-animate">
                        <div class="menu-img img" style="background-image: url(images/10.jpg);"></div>
                        <div class="text">
                            <div class="d-flex">
                                <div class="one-half">
                                    <h3>B. Lochana</h3>
                                </div>
                            </div>
                            <p><span>School of </span> <span>Planning and </span> <span>Architecture</span>, <span>Vijaywada</span></p>
                        </div>
                    </div>
                    <div class="menus d-flex ftco-animate">
                        <div class="menu-img img" style="background-image: url(images/11.jpg);"></div>
                        <div class="text">
                            <div class="d-flex">
                                <div class="one-half">
                                    <h3>K. Satwik</h3>
                                </div>
                            </div>
                            <p><span>Chandigarh </span> <span>Univerity</span> <span>of</span>, <span>Architecture</span></p>
                        </div>
                    </div>
                    <div class="menus d-flex ftco-animate">
                        <div class="menu-img img" style="background-image: url(images/12.jpg);"></div>
                        <div class="text">
                            <div class="d-flex">
                                <div class="one-half">
                                    <h3>N.MAnoj</h3>
                                </div>
                            </div>
                            <p><span>NIT</span> <span>Calicut</span></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 col-lg-4 menu-wrap">
                    <div class="heading-menu text-center ftco-animate">
                    </div>
                    <div class="menus d-flex ftco-animate">
                        <div class="menu-img img" style="background-image: url(images/13.jpg);"></div>
                        <div class="text">
                            <div class="d-flex">
                                <div class="one-half">
                                    <h3>V. Mohit</h3>
                                </div>
                            </div>
                            <p><span>School of </span> <span>Planning and </span> <span>Architecture</span>, <span>Bhopal</span></p>
                        </div>
                    </div>
                    <div class="menus d-flex ftco-animate">
                        <div class="menu-img img" style="background-image: url(images/14.jpg);"></div>
                        <div class="text">
                            <div class="d-flex">
                                <div class="one-half">
                                    <h3>S.Kelika</h3>
                                </div>
                            </div>
                            <p><span>Siddaganga</span> <span>school</span> <span>of</span> <span>Architecture</span></p>
                        </div>
                    </div>
                    <div class="menus d-flex ftco-animate">
                        <div class="menu-img img" style="background-image: url(images/15.jpg);"></div>
                        <div class="text">
                            <div class="d-flex">
                                <div class="one-half">
                                    <h3>Ravi Teja</h3>
                                </div>
                            </div>
                            <p><span>Andhra</span> <span>University</span></p>
                        </div>
                    </div>
                </div>

                <div class="col-md-6 col-lg-4 menu-wrap">
                    <div class="heading-menu text-center ftco-animate">
                    </div>
                    <div class="menus d-flex ftco-animate">
                        <div class="menu-img img" style="background-image: url(images/16.jpg);"></div>
                        <div class="text">
                            <div class="d-flex">
                                <div class="one-half">
                                    <h3>V.Suraj</h3>
                                </div>
                            </div>
                            <p><span>CMR university</span> <span>of</span> <span>Architecture</span>, <span>Bangalore</span></p>
                        </div>
                    </div>
                    <div class="menus d-flex ftco-animate">
                        <div class="menu-img img" style="background-image: url(images/17.jpg);"></div>
                        <div class="text">
                            <div class="d-flex">
                                <div class="one-half">
                                    <h3>D.Manasa</h3>
                                </div>
                            </div>
                            <p><span>Gitma</span> <span>School of</span> <span><br>Architecture</span></p>
                        </div>
                    </div>
                    <div class="menus d-flex ftco-animate">
                        <div class="menu-img img" style="background-image: url(images/18.jpg);"></div>
                        <div class="text">
                            <div class="d-flex">
                                <div class="one-half">
                                    <h3>Traunya</h3>
                                </div>
                            </div>
                            <p><span>JNAFAU</span> <span>Hyderabad</span></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </section>

    <section class="ftco-section testimony-section testimony-section-pc" style="background-image: url(images/bg_5.jpg);background-size:cover;" data-stellar-background-ratio="0.5">
        <div class="container container-fluid">
            <div class="row justify-content-center mb-5 pb-2">
                <div class="col-md-7 text-center heading-section heading-section-white ftco-animate">
                    <span class="subheading" style="color:red;font-size:4.2rem">Testimony</span>

                </div>
            </div>
            <div class="row ftco-animate justify-content-center">
                <div class="col-md-7">
                    <div class="carousel-testimony owl-carousel ftco-owl">

                        <div class="item">
                            <div class="testimony-wrap text-center py-4 pb-5">
                                <div class="user-img mb-4" style="background-image: url(images/person_1.jpg)">
                                    <span class="quote d-flex align-items-center justify-content-center">
                      <i class="icon-quote-left"></i>
                    </span>
                                </div>
                                <div class="text p-3">
                                    <p class="mb-4" style="color:black; font-size:20px">Extraordinary coaching center who are seeking for ranks in JEE B.Arch. Affordable fee, excellent facilities in local area.</p>
                                    <p class="name" style="color:black;font-size:24px;font-weight:500">Amar</p>
                                </div>
                            </div>
                        </div>

                        <div class="item">
                            <div class="testimony-wrap text-center py-4 pb-5">
                                <div class="user-img mb-4" style="background-image: url(images/person_2.jpg)">
                                    <span class="quote d-flex align-items-center justify-content-center">
                      <i class="icon-quote-left"></i>
                    </span>
                                </div>
                                <div class="text p-3">
                                    <p class="mb-4" style="color:black; font-size:20px">Best at individual caring, drawing, aptitude and gives their most effort towards the students.</p>
                                    <p class="name" style="color:black;font-size:24px;font-weight:500">Lalith Harshith</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimony-wrap text-center py-4 pb-5">
                                <div class="user-img mb-4" style="background-image: url(images/person_3.png)">
                                    <span class="quote d-flex align-items-center justify-content-center">
                      <i class="icon-quote-left"></i>
                    </span>
                                </div>
                                <div class="text p-3">
                                    <p class="mb-4" style="color:black; font-size:20px">Best platform for architecture coaching. Teaches wih live examples. The best coaching center...</p>
                                    <p class="name" style="color:black;font-size:24px;font-weight:500">Neelisetty Jaswanth</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimony-wrap text-center py-4 pb-5">
                                <div class="user-img mb-4" style="background-image: url(images/14.jpg)">
                                    <span class="quote d-flex align-items-center justify-content-center">
                      <i class="icon-quote-left"></i>
                    </span>
                                </div>
                                <div class="text p-3">
                                    <p class="mb-4" style="color:black; font-size:20px">Helps student to learn peacefully, which gives a fellow of home learning environment. Stress free learning develops mental status of a person which is also helping for architecture aspiring students.</p>
                                    <p class="name" style="color:black;font-size:24px;font-weight:500">Sampati Kelika</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimony-wrap text-center py-4 pb-5">
                                <div class="user-img mb-4" style="background-image: url(images/4.jpg)">
                                    <span class="quote d-flex align-items-center justify-content-center">
                      <i class="icon-quote-left"></i>
                    </span>
                                </div>
                                <div class="text p-3">
                                    <p class="mb-4" style="color:black; font-size:20px">I am extremely satisfied and happy with coaching I have received here. With the help of artmate, I got into NID with rank of 266. I totally recommend Artmate Trendz!</p>
                                    <p class="name" style="color:black;font-size:24px;font-weight:500">Deepika Yallabandi</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>





<!-- FOR MOBILE -->
<section class=" mobile-testimony"S>
        <div class="container container-fluid">
            <div class="row justify-content-center mb-5 pb-2">
                <div class="col-md-7 text-center heading-section heading-section-white ftco-animate">
                    <span class="subheading" style="color:red;font-size:4.2rem">Testimony</span>

                </div>
            </div>
            <div class="row justify-content-center" >
                <div class="col-md-7">
                    <div class="">

                        <div class="item">
                            <div class="testimony-wrap text-center py-4 pb-5">
                                <div class="user-img mb-4" style="background-image: url(images/person_1.jpg)">
                                    <span class="quote d-flex align-items-center justify-content-center">
                      <i class="icon-quote-left"></i>
                    </span>
                                </div>
                                <div class="text p-3">
                                    <p class="mb-4" style="color:black; font-size:20px">Extraordinary coaching center who are seeking for ranks in JEE B.Arch. Affordable fee, excellent facilities in local area.</p>
                                    <p class="name" style="color:black;font-size:24px;font-weight:500">Amar</p>
                                </div>
                            </div>
                        </div>

                        <div class="item">
                            <div class="testimony-wrap text-center py-4 pb-5">
                                <div class="user-img mb-4" style="background-image: url(images/person_2.jpg)">
                                    <span class="quote d-flex align-items-center justify-content-center">
                      <i class="icon-quote-left"></i>
                    </span>
                                </div>
                                <div class="text p-3">
                                    <p class="mb-4" style="color:black; font-size:20px">Best at individual caring, drawing, aptitude and gives their most effort towards the students.</p>
                                    <p class="name" style="color:black;font-size:24px;font-weight:500">Lalith Harshith</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimony-wrap text-center py-4 pb-5">
                                <div class="user-img mb-4" style="background-image: url(images/person_3.png)">
                                    <span class="quote d-flex align-items-center justify-content-center">
                      <i class="icon-quote-left"></i>
                    </span>
                                </div>
                                <div class="text p-3">
                                    <p class="mb-4" style="color:black; font-size:20px">Best platform for architecture coaching. Teaches wih live examples. The best coaching center...</p>
                                    <p class="name" style="color:black;font-size:24px;font-weight:500">Neelisetty Jaswanth</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimony-wrap text-center py-4 pb-5">
                                <div class="user-img mb-4" style="background-image: url(images/14.jpg)">
                                    <span class="quote d-flex align-items-center justify-content-center">
                      <i class="icon-quote-left"></i>
                    </span>
                                </div>
                                <div class="text p-3">
                                    <p class="mb-4" style="color:black; font-size:20px">Helps student to learn peacefully, which gives a fellow of home learning environment. Stress free learning develops mental status of a person which is also helping for architecture aspiring students.</p>
                                    <p class="name" style="color:black;font-size:24px;font-weight:500">Sampati Kelika</p>
                                </div>
                            </div>
                        </div>
                        <div class="item">
                            <div class="testimony-wrap text-center py-4 pb-5">
                                <div class="user-img mb-4" style="background-image: url(images/4.jpg)">
                                    <span class="quote d-flex align-items-center justify-content-center">
                      <i class="icon-quote-left"></i>
                    </span>
                                </div>
                                <div class="text p-3">
                                    <p class="mb-4" style="color:black; font-size:20px">I am extremely satisfied and happy with coaching I have received here. With the help of artmate, I got into NID with rank of 266. I totally recommend Artmate Trendz!</p>
                                    <p class="name" style="color:black;font-size:24px;font-weight:500">Deepika Yallabandi</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>










<!-- Reservation -->

    <section class="ftco-section ftco-no-pt ftco-no-pb mt-3 p-1">
        <div class="container">
            <div class="row d-flex">
                <div class="col-md-5 ftco-animate img img-2" style="background-image: url(images/reserve.png);"></div>
                <div class="col-md-7 ftco-animate makereservation p-4 p-md-5">
                    <div class="heading-section ftco-animate mb-5">
                        <span class="subheading">Book a Seat</span>
                        <h2 class="mb-4">Make Reservation</h2>
                    </div>
                    <form action="#">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">Name</label>
                                    <input type="text" class="form-control" placeholder="Your Name">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">Email</label>
                                    <input type="text" class="form-control" placeholder="Your Email">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">Phone</label>
                                    <input type="text" class="form-control" placeholder="Phone">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="">Courses</label>
                                    <div class="select-wrap one-third">
                                        <div class="icon"><span class="ion-ios-arrow-down"></span></div>
                                        <select name="" id="" class="form-control">
                        <option value="">JEE B.Arch</option>
                        <option value="">NATA</option>
                        <option value="">NID</option>
                        <option value="">CEPT</option>
                        <option value="">UCEED</option>
                      </select>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12 mt-3">
                                <div class="form-group">
                                    <input type="submit" value="Make a Reservation" class="btn btn-primary py-3 px-5">
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>

</body>

    <script>
    $(document).ready(function() {
        $("#myCarousel").on("click", ".right.carousel-control,.left.carousel-control,.carousel-indicators li", function() {

            var target = $('#myCarousel').find('.item.active');
            if (target.attr('id') === "home") {
                $("#myCarousel").css({
                    'overflow': 'hidden',
                    'height': '100vh'
                });
            } else {
                $("#myCarousel").css({
                    'overflow': 'auto',
                    'height': 'auto'
                });
            }

        });

    });
</script>


<!-- Footer -->
<?php include "includes/footer.php"; ?>